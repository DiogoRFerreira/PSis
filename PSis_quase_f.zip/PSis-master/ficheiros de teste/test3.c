#include "psiskv_lib.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_VALUES 100
int main(){
	char * linha = (char*)malloc(100*sizeof(char));
	int i,a=0;
	int res;


	int kv = kv_connect("192.168.0.105", 9999);
/************************************************/
//	for (i = MAX_VALUES; i > 0; i--){
//		a=i;
//		sprintf(linha, "%u", i);
//		kv_write(kv, a , linha, strlen(linha)+1, 0);
//		printf("key[%d] value[%s]\n",a,linha);
//	}
//	getchar();
	for (i = 0; i < MAX_VALUES; i++){
		a=i+1;
		sprintf(linha, "%u", i);
		kv_write(kv, a , linha, strlen(linha)+1, 0);
		printf("key[%d] value[%s]\n",a,linha);
	}
	getchar();
		printf("QUASE1\n - Retrieve");
	for ( i = 0; i < MAX_VALUES+5; i++){
		res = kv_read(kv, i , &linha, 1000);
		if( res>= 0){
			printf ("key[%u] value[%s]\n", i, linha);
		}else{
			printf("Key %u doesn't exist. returned value %d\n", i, res);
		}

	}
	getchar();
	printf("QUASE2\n");
	for (i = 0; i < MAX_VALUES; i++){
		sprintf(linha, "%u", i+2);
		kv_write(kv, i , linha, strlen(linha)+1, 1);
	}
	getchar();
		printf("QUASE3\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i ,&linha, 1000) == 0){
			printf ("key - %u value %s\n", i, linha);
		}
	}
	getchar();
		printf("QUASE4\n");
	for (i = 0; i < MAX_VALUES; i++){
		kv_delete(kv, i);
	}
	getchar();
		printf("QUASE5\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %u value %s\n", i, linha);
		}
	}
	getchar();
		printf("QUASE6\n");
/************************************************/
	for (i = MAX_VALUES; i > 0; i--){
		sprintf(linha, "%u", i);
		kv_write(kv, i , linha, strlen(linha)+1, 0);
	}
	getchar();
		printf("QUASE7\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %u value %s\n", i, linha);
		}
	}
	getchar();
		printf("QUASE8\n");
	for (i = MAX_VALUES; i > 0; i--){
		sprintf(linha, "%u", i);
		kv_write(kv, i , linha, strlen(linha)+1, 1);
	}
	getchar();
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
		printf("QUASE9\n");
	for (i = MAX_VALUES; i > 0; i--){
		kv_delete(kv, i);
	}
	getchar();
		printf("QUASE10\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
		printf("QUASE11\n");
/************************************************/
	for (i = MAX_VALUES; i > 0; i=i-2){
		sprintf(linha, "%u", i);
		printf("i: %d\n", i);
		kv_write(kv, i , linha, strlen(linha)+1, 0);
	}
	getchar();
	printf("QUASE12\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
	printf("QUASE13\n");
	for (i = MAX_VALUES; i > 0; i-=2){
		sprintf(linha, "%u", i);
		kv_write(kv, i , linha, strlen(linha)+1, 1);
	}
	getchar();
	printf("QUASE14\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
	printf("QUASE15\n");
	for (i = MAX_VALUES; i > 0; i-=2){
		kv_delete(kv, i);
	}
	getchar();
	printf("QUASE16\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
	printf("QUASE17\n");
/************************************************/
	for (i = MAX_VALUES; i > 0; i-=3){
		sprintf(linha, "%u", i);
		kv_write(kv, i , linha, strlen(linha)+1, 0);
		printf ("i: %d\n",i);
	}
	getchar();
	printf("QUASE18\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
	printf("QUASE19\n");
	for (i = MAX_VALUES; i > 0; i-=3){
		sprintf(linha, "%u", i);
		kv_write(kv, i , linha, strlen(linha)+1, 1);
	}
	getchar();
	printf("QUASE20\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
	printf("QUASE21\n");
	for (i = MAX_VALUES; i > 0; i-=3){
		kv_delete(kv, i);
	}
	getchar();
	printf("QUASE22\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
	printf("QUASE23\n");
/************************************************/
	for (i = 0; i < MAX_VALUES; i+=4){
		sprintf(linha, "%u", i);
		kv_write(kv, i , linha, strlen(linha)+1, 0);
	}
	getchar();
	printf("QUASE24\n");
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	getchar();
	printf("QUASE25\n");
	for (i = 0; i < MAX_VALUES; i+=4){
		sprintf(linha, "%u", i+2);
		kv_write(kv, i , linha, strlen(linha)+1, 1);
	}
	printf("QUASE\n");
getchar();
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	printf("Aqui\n");
	getchar();
	for (i = 0; i < MAX_VALUES; i+=4){
		kv_delete(kv, i);
	}
	printf("LOL\n");
	getchar();
	for ( i = 0; i < MAX_VALUES; i ++){
		if(kv_read(kv, i , &linha, 1000) == 0){
			printf ("key - %10u value %s\n", i, linha);
		}
	}
	printf("FIM\n");
/************************************************/


	kv_close(kv);


}
