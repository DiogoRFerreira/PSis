#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>

#include "psiskv_list.h"
#include "psiskv_server.h"//mutex

node * head = NULL;

//Print of the list - just for debug
void print_list(){

    node * current = head;
    printf("--------------------- Printing list --------------------------\n\n");
    pthread_rwlock_rdlock(&rwlock);//Lock de leitura para correr a lista
   // printf(".................RW READ LOCK 1.................\n");
    if (current==NULL) {
        printf("Empty list\n");
    }else{
        while (current!=NULL) {

            printf("Key: %u				Value: %s\n",current->key,current->value);
            current=current->next;
        }
    }
    //free(current);
    pthread_rwlock_unlock(&rwlock);
    //printf(".................RW READ UNLOCK 1.................\n");
    printf("\n");
    printf("--------------------- END OF Printing list -------------------\n\n");
}

// Retrieve value from list if it exists
int read_value(uint32_t key, char * p){

    //Critical Region
	pthread_rwlock_rdlock(&rwlock);
	//printf(".................RW READ LOCK 1.................\n");
	node * current = head;
	while (current!=NULL) {
		if(current->key==key){

			//Critical Region 2
			pthread_rwlock_rdlock(&rwlock2);
			//printf(".................RW READ LOCK 2.................\n");
			strcpy(p,current->value);
			//printf("=== Critical region [READ]: read value [%s]	copied value[%s]\n", current->value,*p);
			//free(current);
			pthread_rwlock_unlock(&rwlock2);
			//printf(".................RW READ UNLOCK 2.................\n");

			pthread_rwlock_unlock(&rwlock);
			//printf(".................RW READ UNLOCK 1.................\n");
			return (int)(sizeof(p));
        }
        current=current->next;
    }

    pthread_rwlock_unlock(&rwlock);
    //printf(".................RW READ UNLOCK 1.................\n");
    return -2;
}

// Insert
int add_value(uint32_t key, char * value, int overwrite) {

    node * current, * previous;
    node * new_element = (node*)malloc(sizeof(node));
	new_element->key=key;
	//copy value
	new_element->value = (char*)malloc(strlen(value)*sizeof(char));
	strcpy((new_element->value),value);
    int returnvalue=0;
    int added=0;

    //Critical Region
  //  printf("................. TRY RW READ LOCK 1.................\n");
    pthread_rwlock_rdlock(&rwlock);//Lock de leitura para correr a lista
   // printf(".................RW READ LOCK 1.................\n");
  //  printf(".................TRY RW MUTEX LOCK 1.................\n");
    pthread_mutex_lock(&lock);//Só um add de cada vez
 //   printf(".................RW MUTEX LOCK 1.................\n");
	if(head==NULL){ //Lista vazia
    //    printf(".................TRY RW WRITE LOCK.................\n");
      pthread_rwlock_wrlock(&rwlock2);//Lock de escrita para inserir na lista
    //    printf(".................RW WRITE LOCK.................\n");
		head = new_element;
		head->next = NULL;
	//	 printf("................. TRY RW WRITE UNLOCK.................\n");
		pthread_rwlock_unlock(&rwlock2);
		// printf(".................RW WRITE UNLOCK.................\n");
	//	printf("=== Critical region: insert value -> empty list\n");
    }else if(head->next==NULL){ //Só existe um elemento na lista
        pthread_rwlock_wrlock(&rwlock2);
      //  printf(".................RW WRITE LOCK.................\n");
        if (key > head->key){
            head->next = new_element;
            new_element->next = NULL;
        }else if(key < head->key){
            new_element->next = head;
            head = new_element;
        }else{
            if(overwrite == 0)returnvalue=-2;
            else if(overwrite == 1){
                free(head->value);
                head->value = (char*)malloc(strlen(value)*sizeof(char));
                strcpy(head->value,new_element->value);
                free(new_element->value);
                free(new_element);
                printf("=== Critical region 1 ELEMENT: UPDATE value: %s\n", head->value);
            }
        }
      //  printf(".................TRY RW WRITE UNLOCK.................\n");
        pthread_rwlock_unlock(&rwlock2);
      //  printf(".................RW WRITE UNLOCK.................\n");
      //  printf("=== Critical region: insert value -> only 1 element in list\n");
	}else{ 	//Mais do que um elemento na lista
        // Initialize pointers
        current = head;
        previous = head;

		while (added!=1) {
			//printf(" . ");
			if(current->key == key) {		// Found element with key
                if(overwrite == 0)returnvalue=-2;
                else if(overwrite == 1){
                 //   printf("................. TRY RW WRITE LOCK.................\n");
                    pthread_rwlock_wrlock(&rwlock2);
                    free(current->value);
                    current->value = (char*)malloc(strlen(value)*sizeof(char));
                 //   printf(".................RW WRITE LOCK.................\n");
                    strcpy((current->value),(new_element->value));
                  //   printf(".................TRY RW WRITE UNLOCK.................\n");
                    free(new_element->value);
					free(new_element);
					printf("=== Critical region: UPDATE value, value (temporary): %s\n", current->value);
                    pthread_rwlock_unlock(&rwlock2);
                   // printf(".................RW WRITE UNLOCK.................\n");

                }
                added=1;

			}else if (key > current->key) {
				if (current->next!=NULL) {
					//printf("=== Searching in insert... Current key[%u] value[%s]\n", current->key,current->value);
					previous = current;
					current = current->next;
				} else {
                //    printf(".................TRY RW WRITE LOCK.................\n");
                    pthread_rwlock_wrlock(&rwlock2);
                 //   printf(".................RW WRITE LOCK.................\n");
					current->next = new_element;

					current->next->next = NULL;
					pthread_rwlock_unlock(&rwlock2);
					//printf(".................RW WRITE UNLOCK.................\n");
				//	printf("=== Critical region: insert value AFTER, current (temporary): %s\n", new_element->value);
                    added=1;
				}
            }else if(key < current->key ){
				//  printf("................. TRY RW WRITE LOCK.................\n");
                pthread_rwlock_wrlock(&rwlock2);
               // printf(".................RW WRITE LOCK.................\n");
                new_element->next = current;
				if (head == current) {
					head = new_element;
				}/*else{
					current->next = new_element;
				}*/
				//printf("................. TRY RW WRITE LOCK.................\n");
                pthread_rwlock_unlock(&rwlock2);
               // printf(".................RW WRITE LOCK.................\n");
				added=1;
				//printf("=== Critical region: insert value BEFORE, value (temporary): %s\n", new_element->value);
			}
		}
	}

	//printf(".................TRY RW MUTEX UNLOCK.................\n");
    pthread_mutex_unlock(&lock);
   // printf(".................RW MUTEX UNLOCK.................\n");
   // printf("................. TRY RW READ UNLOCK 1.................\n");
    pthread_rwlock_unlock(&rwlock);
    //printf(".................RW READ UNLOCK 1.................\n");

    return returnvalue;
}

// Delete
int delete_value(uint32_t key){

    node * previous, * current = head;
    int deleted=0;
    int found=0;



    previous = current;
    //Critical Region
	pthread_rwlock_wrlock(&rwlock);
	if(head==NULL) return -1;
    while (!found) {
        if(key == (current->key)){
			found=1;
        }else{
			previous = current;
			if(current->next==NULL) return -1;
			current = current->next;
		}
    }

    if(found){
			//Critical Region 2
			pthread_rwlock_wrlock(&rwlock2);
            if ((head->next)==NULL) {
                free(head->value);
                head = NULL;
            }else if (current==head){
                head = current->next;
                free(current->value);
                free(current);
            }else{
                previous->next = current->next;
                free(current->value);
                free(current);
            }
            deleted=1;
            pthread_rwlock_unlock(&rwlock2);
	}
    pthread_rwlock_unlock(&rwlock);
    return deleted;
}

//Backup
void build_backup(FILE * fp){
    node * current;

    pthread_rwlock_rdlock(&rwlock); //Enquanto faz backup só podem ler da lista
    //pthread_mutex_lock(&lock);//Só um add de cada vez
    current=head;
    while(current!=NULL){
		//mutex para escrever no backup
		pthread_rwlock_rdlock(&rwlock2);
        fprintf(fp,"%u %u\n",current->key ,(unsigned int)strlen(current->value));
        fprintf(fp,"%s\n",current->value);
        pthread_rwlock_unlock(&rwlock2);
        current=current->next;

    }
    //pthread_mutex_unlock(&lock);//Só um add de cada vez
    pthread_rwlock_unlock(&rwlock);
    fclose(fp);
}
