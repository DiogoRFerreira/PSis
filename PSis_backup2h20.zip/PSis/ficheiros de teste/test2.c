#include "psiskv_lib.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_VALUES 400
int main()
{
char * linha = ( char* ) malloc ( 100 * sizeof ( char ) );
        int i;
    //int kv = kv_connect("192.168.0.105", 9999);
    int pid = getpid();
    printf ( "Father pid: %d\n", pid );
    if ( fork() == 0 )
    {

        int kv = kv_connect ( "192.168.0.105", 9999 );
        pid = getpid();
        printf ( "pid: %d\n", pid );
        for ( i = 0; i < MAX_VALUES; i ++ )
        {
            sprintf ( linha, "%u", i );
            kv_write ( kv, i , linha, strlen ( linha ) + 1, 0 );
            printf ( "--write-- pid: %d		i[%d]\n", pid , i );
        }
        int res;
        /*for ( i = 0; i < MAX_VALUES; i ++ )
        {
            res = kv_read ( kv, i , &linha, 1000 );
            if ( res >= 0 )
            {
                printf ( "--read-- pid: %d 	key - %10u value %s\n", pid, i, linha );
            }
            else
            {
                printf ( "--read-- pid: %d	Key[%d] doesn't exist. return value[%d]\n", pid, i, res );
            }
        }


        for ( i = 0; i < MAX_VALUES; i += 2 )
        {
            kv_delete ( kv, i );
        }*/
        kv_close(kv);

    }
    else
    {

        int kv = kv_connect ( "192.168.0.105", 9999 );
        pid = getpid();
        printf ( "######################pid: %d\n", pid );

        for ( i = 0; i < MAX_VALUES; i ++ )
        {
            sprintf ( linha, "%u", i );
            kv_write ( kv, i , linha, strlen ( linha ) + 1, 0 );
            printf ( "--write-- pid: %d		i[%d]\n", pid , i );
        }

        /*wait(NULL);
        for ( i = 0; i < MAX_VALUES; i ++ )
        {
            sprintf ( linha, "%u", i );
            kv_write ( kv, i , linha, strlen ( linha ) + 1, 0 );
            printf ( "--write-- pid: %d		i[%d]\n", pid , i );
        }*/
        kv_close(kv);
    }
	return 1;

}
