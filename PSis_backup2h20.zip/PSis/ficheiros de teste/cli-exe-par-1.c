#include "psiskv_lib.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_VALUES 5
int main(){
	char * linha = (char*)malloc(100*sizeof(char));
	uint32_t i;
	int res=-2;
	if(fork() == 0){
		//printf("Entrou no filho\n");
		int kv = kv_connect("192.168.0.105", 9999);
		//printf("Entrou no filho2 kv: %d\n",kv);
		for (i = 1; i < 6; i ++){
			sprintf(linha, "%u", i);
			kv_write(kv, i , linha, strlen(linha), 0);
			printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha, getpid(), 0);
			//printf ( "--filho--\n" );
		}
		kv_close(kv);


	}else{
		//printf("Entrou no pai \n");
		int kv = kv_connect("192.168.0.105", 9999);
		//printf("Entrou no pai2 kv: %d\n", kv);
		for (i =1; i < 11; i ++){
			sprintf(linha, "%u", i);
			kv_write(kv, i , linha, strlen(linha), 0);
			printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha,getpid(),0);
			//printf ( "--pai--\n" );
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		
		
		wait(NULL);
		for (i = 0; i < 11; i ++){
            res = kv_read ( kv, i , linha, 1000 );
            if ( res >= 0 )
            {
                printf("-- R --  		%u	|	%s\n", i,linha);
            }
            else
            {
                printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
            }
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		
		for (i = 1; i < 11; i=i+2){
            kv_delete(kv, i);
            printf("-- D --  	%u			(if exists)\n", i);
            
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		
		for (i = 1; i < 11; i ++){
            res = kv_read ( kv, i , linha, 1000 );
            if ( res >= 0 )
            {
                printf("-- R --  		%u	|	%s\n", i,linha);
            }
            else
            {
                printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
            }
		}
		
		
		printf("\n------------------------------------------------------------------------------\n\n");
		
		for (i = 2; i < 11; i=i+2){
            kv_delete(kv, i);
            printf("-- D --  	%u			(if exists)\n", i);
            
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		
		for (i = 1; i < 11; i ++){
            res = kv_read ( kv, i , linha, 1000 );
            if ( res >= 0 )
            {
                printf("-- R --  		%u	|	%s\n", i,linha);
            }
            else
            {
                printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
            }
		}
	kv_close(kv);
	}
		if(fork() == 0){
			int kv = kv_connect("192.168.0.105", 9999);
			for (i = 1; i < 11; i ++){
				sprintf(linha, "%u", i);
				kv_write(kv, i , linha, strlen(linha), 0);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha, getpid(), 0);
			}
			kv_close(kv);
		}else{
			int kv = kv_connect("192.168.0.105", 9999);
			for (i = 1; i < 11; i ++){
				sprintf(linha, "%u", i*10);
				kv_write(kv, i , linha, strlen(linha), 1);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha, getpid(),1);
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			wait(NULL);
			for (i = 1; i < 11; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
				}
			}
		printf("\n------------------------------------------------------------------------------\n\n");
		
		for (i = 1; i < 11; i++){
            kv_delete(kv, i);
            printf("-- D --  	%u			(if exists)\n", i);
		}
		
		
		printf("\n------------------------------------------------------------------------------\n\n");
			for (i = 1; i < 11; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
		kv_close(kv);
		}
		
		if(fork() == 0){
			int kv = kv_connect("192.168.0.105", 9999);
			
			for (i = 100; i < 105; i ++){
				sprintf(linha, "%u", i);
				kv_write(kv, i , linha, strlen(linha), 0);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d l:%d\n", i,linha, getpid(), 0, strlen(linha));
			}
			kv_close(kv);
		}else{
			int kv = kv_connect("192.168.0.105", 9999);

			for (i = 100; i < 105; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			wait(NULL);
			for (i = 100; i < 105; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			for (i = 100; i < 105; i++){
				kv_delete(kv, i);
				printf("-- D --  	%u			(if exists)\n", i);
				
			}
			printf("\n------------------------------------------------------------------------------\n\n");
						for (i = 100; i < 105; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
						for (i = 100; i < 105; i ++){
				sprintf(linha, "%u", i);
				kv_write(kv, i , linha, strlen(linha), 0);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d l:%d\n", i,linha, getpid(), 0,strlen(linha));
			}
			printf("\n------------------------------------------------------------------------------\n\n");
						for (i = 100; i < 105; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
						//for (i = 100; i < 105; i++){
				//kv_delete(kv, i);
				//printf("-- D --  	%u			(if exists)\n", i);
				
			//}
			printf("\n------------------------------------------------------------------------------\n\n");
									for (i = 100; i < 105; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. return value[%d]\n", i, res );
				}
			}
			
			kv_close(kv);
			printf("\n------------------------------------------------------------------------------\n\n");
		
		


	}
		
		
	
	
	
}
