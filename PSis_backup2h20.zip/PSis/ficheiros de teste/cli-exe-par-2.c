#include "psiskv_lib.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_VALUES 5
int main(){
	char * linha = (char*)malloc(100*sizeof(char));
	uint32_t i;
	int res=-2;


}
