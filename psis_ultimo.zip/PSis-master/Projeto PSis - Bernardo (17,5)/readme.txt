run "make clean" to be sure that no binary files are in your directory

type "make relauncher" and "make client" 

./relauncher

./client

run "ifconfig" in your computer where you ran the relauncher binary and introduce the correspondant ip 
in the client program