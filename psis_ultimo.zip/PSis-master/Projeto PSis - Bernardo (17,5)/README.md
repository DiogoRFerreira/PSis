
The purpose of this assigment was to build a basic chatroom.
It is build based on a client-server architecture. The client is able to send requests and messages, the server receives then and sends the response or broadcasts the messages to all the other clients (depending on the client message)

On the server side its also possible to check all the logs done since the program started.

The client can ask for older messages

Just check the readme.txt, follow the compile instructions and enjoy :)

The code only has two known bugs, feel free to find and correct then and if you do, please let me know :)
