
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_VALUES 100
int main()
{
    int i;
    int pid = getpid();
    printf ( "Father pid: %d\n", pid );
    if ( fork() == 0 )
    {
        pid = getpid();
        printf ( "pid: %d\n", pid );
        for ( i = 0; i < MAX_VALUES; i ++ )
        {
            printf ( "** pid: %d		i[%d]\n", pid , i );
        }

    }
    else
    {
        pid = getpid();
        printf ( "pid: %d\n", pid );

                for ( i = 0; i < MAX_VALUES; i ++ )
        {
            printf ( "== pid: %d		i[%d]\n", pid , i );
        }

    }
	return 1;

}
