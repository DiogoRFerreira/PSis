#include "psiskv_lib.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_VALUES 5
int main(){
	char * linha = (char*)malloc(100*sizeof(char));
	uint32_t i;
	int res=-2;
	if(fork() == 0){
		int kv = kv_connect("192.168.0.105", 9999);
				printf("\n");
		printf("Inserting key [1..5] values [1..5]\n");
				printf("\n");
		for (i = 1; i < 6; i ++){
			sprintf(linha, "%u", i);
			kv_write(kv, i , linha, strlen(linha), 0);
			printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha, getpid(), 0);
		}
		kv_close(kv);


	}else{
		int kv = kv_connect("192.168.0.105", 9999);
		printf("\n");
		printf("Inserting key [1..20] values [1..20]\n");
		printf("\n");
		for (i =1; i < 21; i ++){
			sprintf(linha, "%u", i);
			kv_write(kv, i , linha, strlen(linha), 0);
			printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha,getpid(),0);
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		
		
		wait(NULL);
		printf("\n");
		printf("Reading key [0..20] \n");
		printf("\n");
		for (i = 0; i < 21; i ++){
            res = kv_read ( kv, i , linha, 1000 );
            if ( res >= 0 )
            {
                printf("-- R --  		%u	|	%s\n", i,linha);
            }
            else
            {
                printf ( "Key[%u] doesn't exist. \n", i, res );
            }
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		printf("Deleting key [1..20]	--> odd values\n");
		printf("\n");
		for (i = 1; i < 21; i=i+2){
            kv_delete(kv, i);
            printf("-- D --  	%u			(if exists)\n", i);
            
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		printf("Reading key [1..20]\n");
		printf("\n");
		for (i = 1; i < 21; i ++){
            res = kv_read ( kv, i , linha, 1000 );
            if ( res >= 0 )
            {
                printf("-- R --  		%u	|	%s\n", i,linha);
            }
            else
            {
                printf ( "Key[%u] doesn't exist.\n", i);
            }
		}
		
		
		printf("\n------------------------------------------------------------------------------\n\n");
		printf("Deleting key [2..20]	--> even values\n");
		printf("\n");
		for (i = 2; i < 21; i=i+2){
            kv_delete(kv, i);
            printf("-- D --  	%u			(if exists)\n", i);
            
		}
		printf("\n------------------------------------------------------------------------------\n\n");
		printf("Reading key [1..20]	\n");
		printf("\n");
		for (i = 1; i < 21; i ++){
            res = kv_read ( kv, i , linha, 1000 );
            if ( res >= 0 )
            {
                printf("-- R --  		%u	|	%s\n", i,linha);
            }
            else
            {
                printf ( "Key[%u] doesn't exist.\n", i);
            }
		}
		kv_close(kv);
		}
		printf("\n");
		printf("Inserting concurrently with OW 0 & 1 key [1..20] values [1..20] & [10..200]\n");
		printf("\n");
		if(fork() == 0){
			
			int kv = kv_connect("192.168.0.105", 9999);
			
			for (i = 1; i < 21; i ++){
				sprintf(linha, "%u", i);
				kv_write(kv, i , linha, strlen(linha), 0);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha, getpid(), 0);
			}
			kv_close(kv);
		}else{
			int kv = kv_connect("192.168.0.105", 9999);
			for (i = 1; i < 21; i ++){
				sprintf(linha, "%u", i*10);
				kv_write(kv, i , linha, strlen(linha), 1);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d\n", i,linha, getpid(),1);
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			wait(NULL);
			
			printf("Reading key [1..20]\n");
			printf("\n");
			for (i = 1; i < 21; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist.\n", i);
				}
			}
		printf("\n------------------------------------------------------------------------------\n\n");
		printf("Deleting key [1..20]\n");
		printf("\n");
		for (i = 1; i < 21; i++){
            kv_delete(kv, i);
            printf("-- D --  	%u			(if exists)\n", i);
		}
		
		
		printf("\n------------------------------------------------------------------------------\n\n");
		printf("Reading key [1..20]\n");
		printf("\n");
			for (i = 1; i < 21; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. \n", i);
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
		kv_close(kv);
		}
		printf("\n");
		printf("Inserting & reading concurrently the same keys[100000..100010] values[100000..100010]\n");
		printf("\n");
		if(fork() == 0){
			int kv = kv_connect("192.168.0.105", 9999);
			
			for (i = 100000; i < 100010; i ++){
				sprintf(linha, "%u", i);
				kv_write(kv, i , linha, strlen(linha), 0);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d l:%d\n", i,linha, getpid(), 0, strlen(linha));
			}
			kv_close(kv);
		}else{
			int kv = kv_connect("192.168.0.105", 9999);

			for (i = 100000; i < 100010; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist.\n", i);
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			wait(NULL);
		printf("Reading keys[100000..100010]\n");
		printf("\n");
			for (i = 100000; i < 100010; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist.\n", i);
				}
			}
		printf("Deleting keys[100000..100010]\n");
		printf("\n");
			printf("\n------------------------------------------------------------------------------\n\n");
			for (i = 100000; i < 100010; i++){
				kv_delete(kv, i);
				printf("-- D --  	%u			(if exists)\n", i);
				
			}
			printf("\n------------------------------------------------------------------------------\n\n");
		printf("Reading keys[100000..100010]\n");
		printf("\n");
						for (i = 100000; i < 100010; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. \n", i);
				}
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			printf("Inserting keys[100000..100010] values[100000..100010]\n");
			printf("\n");
			for (i = 100000; i < 100010; i ++){
				sprintf(linha, "%u", i);
				kv_write(kv, i , linha, strlen(linha), 0);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d l:%d\n", i,linha, getpid(), 0,strlen(linha));
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			printf("Overwriting keys[100000..100010] values [1..10] \n");
			printf("\n");
			for (i = 100000; i < 100010; i ++){
				sprintf(linha, "%u", i-100000);
				kv_write(kv, i , linha, strlen(linha), 1);
				printf("-- W --  		%u	|	%s		pid: %d		OW: %d l:%d\n", i,linha, getpid(), 0,strlen(linha));
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			printf("Reading keys[100000..100010]\n");
			printf("\n");
			for (i = 100000; i < 100010; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist. \n", i);
				}
			}
			
			printf("\n------------------------------------------------------------------------------\n\n");
			printf("Deleting keys[100000..100010]\n");
			printf("\n");
			for (i = 100000; i < 100010; i++){
				kv_delete(kv, i);
				printf("-- D --  	%u			(if exists)\n", i);
				
			}
			printf("\n------------------------------------------------------------------------------\n\n");
			printf("Reading keys[100000..100010]\n");
			printf("\n");
			for (i = 100000; i < 100010; i ++){
				res = kv_read ( kv, i, linha, 1000 );
				if ( res >= 0 )
				{
					printf("-- R --  		%u	|	%s\n", i,linha);
				}
				else
				{
					printf ( "Key[%u] doesn't exist.\n", i);
				}
			}
			
			kv_close(kv);
			printf("\n--------------------	List shall be empty now.	--------------------------------\n\n");

	}
}
